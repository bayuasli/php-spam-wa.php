# Command In Termux        
```
pkg update && pkg upgrade -y         
pkg install git -y         
pkg instal php -y       
git clone https://github.com/hanx-666/spam-wa       
cd spam-wa        
php spam.php        
